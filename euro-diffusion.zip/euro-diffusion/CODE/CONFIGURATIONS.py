input_filepath = './data/input.txt'
grid_size = 10
max_countries_amount = 20
initial_city_balance = 1_000_000
representative_portion = 1_000
